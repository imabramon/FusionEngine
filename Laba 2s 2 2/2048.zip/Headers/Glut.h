//Подключение глут
#include <GLUT/GLUT.h>
