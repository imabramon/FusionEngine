#ifndef Colors_h
#define Colors_h

#define WHITE 255,255,255
#define GREY 128,128,128
#define BLACK 0,0,0

#define RED 255,0,0
#define GREEN 0,255,0
#define BLUE 0,0,255

#define YELLOW 255,255,0
#define PINK 255,0,255
#define TURQUOISE 0,255,255

#define ORANGE 255,128,0
#define PURPLE 128,0,255

#endif 
